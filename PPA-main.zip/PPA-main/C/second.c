static int no = 11;   // global static variable

//error