#include <stdio.h>
int main (int argc, char **argv)
{
    int i = 0;
    i = 1; //1
    do
    {
        printf("jay Ganesh...\n");//4
        i++;//3
    }while (i<= 5);//2
    return 0;
}