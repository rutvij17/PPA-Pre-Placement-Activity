#include <stdio.h>

int main()
{
    printf ("Jay Gajanan ...\n");
    return 0;
    
} 


// gcc Demo.c -o Myexe
// Myexe Demo.c   or
// Myexe.
