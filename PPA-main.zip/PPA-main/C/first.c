#include <stdio.h>

int x = 21;
extern int no;
 int main(int argc, char **argv)
 {
printf("%d\n",x);
printf("%d\n",no);

    return 0;
    
 }

 //error