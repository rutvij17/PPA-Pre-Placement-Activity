
#include <stdio.h>

int no  = 11;//global variable karan ha konachya hi opening closing madhe nahi ahe 
void marvellous ()
{
    printf("inside Marvellous\n");

}