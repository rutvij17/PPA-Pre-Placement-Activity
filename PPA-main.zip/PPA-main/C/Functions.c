#include<stdio.h>

void Display()

{
    printf("My Name is Shivranjan Pathak\n");
}
int main()
{
    printf ("Inside main function\n");
    Display();
    printf("End of main\n");
    return 0;
    

}
