#include <stdio.h>
int main ()
{
    int no =11;
    int *ptr =&no;
    printf("%d\n",*ptr);

    return 0;

}