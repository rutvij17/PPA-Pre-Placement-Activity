//inbuilt header file

#include <stdio.h>
//user defined header file
#include "ppa.h"
int main(int argc, char **argv)
{
    struct Demo object;
    float f = PI;
    printf("%f\n,f");



    return 0;

}

//gcc filename.c -o myexe