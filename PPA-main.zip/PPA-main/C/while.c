#include <stdio.h>
int main (int argc, char **argv)
{
    int i = 0;
    i = 1; //1
    while (i<= 5);//2
    {
        printf("jay Ganesh...\n");//4
        i++;//3
    }
    return 0;
}