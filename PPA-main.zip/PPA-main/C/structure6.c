#include <stdio.h>
struct Demo
{
    int data;
    struct Demo obj;  //Error

    
};
int main(int argc, char **argv)
{
    
    return 0;

}