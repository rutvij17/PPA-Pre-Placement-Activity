#include <stdio.h>
//its a entry point function 

#define DOZEN 12
int main ()
{
    int no = DOZEN;

    printf("Jay Mahakal...\n");
    printf("%d\n",no);
    return 0;


}


//gcc filename.c -save-temps -o myexe
/*----------------------------------------------------------------





*/