struct Demo
{
    int no;
    int x;

};

#define PI 3.14
