#include <stdio.h>
int main (){
    char ch = 'S';
    int i = 99;
    float f = 89.99;
    double d = 90.00089;
    







    return 0;
}