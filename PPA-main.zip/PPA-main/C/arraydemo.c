#include <stdio.h>
int main (){
    int Marathi =89;
    int Hindi =78;
    int History = 80;
    int Maths = 98;
    int Sanskrit = 77;


    int Marks [5]={89,78,80,98,77};
    //MArks is one dimensional array which contains 5 elements and each element is of type integer type







    return 0;

}