#include <stdio.h>

int main()
{
    int A = 0;
    int B = 0;
    int Ans = 0;
    printf ("Enter First Number :\n ");
    scanf ("%d", &A);

    printf ("Enter Second  Number :\n ");
    scanf ("%d", &B);

    Ans = A + B;
    printf ("Addition is :%d\n",Ans); 

    return 0;

}