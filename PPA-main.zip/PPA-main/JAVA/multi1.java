class multi1
{
    public static void main (String A[])
    {
        String name = Thread.currentThread().getName();
        System.out.println("Name of the Thread is "+name );
        
    }
}