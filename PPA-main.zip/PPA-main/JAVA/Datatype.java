class Datatype 
{
    public static void main (String Arg[])
    {
        int no = 11;
        float f = 3.14f ;
        double d = 89.999;
        char ch = 'A';


        System.out.println(no);
        System.out.println(f);
        System.out.println(d);
        System.out.println(ch);
    }
}