class Demo
{
    public int A;
    private int B;
    protected int C;
    int D; // package-private
}

class access
{
    public static void main (String Arg[])
    {


        return 0;
    
    }
}