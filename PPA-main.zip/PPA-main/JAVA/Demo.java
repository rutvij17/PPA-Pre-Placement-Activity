class Demo 
{
    public static void main (String Arg[])
    {
        System.out.println("Jay Ganesh ... ");
    }
}

// javac Demo.java
// java Demo or java Demo.java