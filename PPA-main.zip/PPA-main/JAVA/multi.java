class multi
{
    public static void main (String Arg[])
    {


    int Arr[][] = new int [3][4];
    Arr [0][0] = 10;
    Arr [0][1] = 11;
    Arr [0][2] = 12;
    Arr [0][3] = 13;

    Arr [1][0] = 14;
    Arr [1][1] = 15;
    Arr [1][2] = 16;
    Arr [1][3] = 17;

    Arr [2][0] = 18;
    Arr [2][1] = 19;
    Arr [2][2] = 20;
    Arr [2][3] = 21;
}
}