class Arraydemo{
    public static void main (String  Arg[])
    {
        

       //int Arr[] = {10,20,30,40,50};
       int Arr[] = new int[]{10,20,30,40,50};



        System.out.println("number of elements in array are : "+Arr.length);

        System.out.println(Arr[0]);
        System.out.println(Arr[1]);
        System.out.println(Arr[2]);
        System.out.println(Arr[3]);
        System.out.println(Arr[4]);


    }
}

