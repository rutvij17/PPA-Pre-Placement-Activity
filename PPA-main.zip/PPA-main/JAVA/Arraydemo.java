class Arraydemo{
    public static void main (String  Arg[])
    {
        int Arr[] = new int [5]; //Declare and initialize an array of size 5.

        Arr[0] = 12; 
        Arr[1]= 11;
        Arr[2]= 22;
        Arr[3]= 34;
        Arr[4]= 25;




        System.out.println("number of elements in array are : "+Arr.length);

        System.out.println(Arr[0]);
        System.out.println(Arr[1]);
        System.out.println(Arr[2]);
        System.out.println(Arr[3]);
        System.out.println(Arr[4]);


    }
}