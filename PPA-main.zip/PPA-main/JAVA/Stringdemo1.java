class StringDemo1
{
    public static void main (String[] args) 
    {
        String s1 = "Hello";
        String s2 = new String ("Hello");
        String s3 = "Demo";
        String s4 = new String ("java");
        
        String s5 = "Hello";
        String s6 = "Demo";
        String s7 = "Marvellous";
        String s8 = new String ("Hello");
        String s9 = new String ("PPA");
        String s10 = "PPA";
    } 
}