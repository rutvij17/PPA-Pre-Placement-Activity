final class Base 
{
   
}

class Derived extends Base 
{
   
}
class final3
{
    public static void main(String A[])
    {
       
    }
}
