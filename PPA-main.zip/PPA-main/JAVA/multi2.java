class multi2
{
    public static void main (String A[])
    {

    }
}
class Demo extends Thread 
{
    public void run()
    {
        //logic
    }
}
class Hello implements Runnable 
{

    public void run()
    {
        //logic
    }
}