#include<iostream>

namespace Marvellous
{
    class Demo
    {

    };
}
namespace PPA
{
    class Hello
    {

    };
}
int main()
{
    std ::cout <<"Inside main\n";
    Marvellous::Demo dobj;
    PPA ::Hello hobj;



    return 0;
}