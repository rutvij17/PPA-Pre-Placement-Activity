#include<iostream>

using namespace std;
int main (int argc, char **argv)
{
    cout << "Jay Ganesh....\n";



    return 0;
}

//g++ demo.cpp -o myexe
//myexe.exe
//./myexe---linux